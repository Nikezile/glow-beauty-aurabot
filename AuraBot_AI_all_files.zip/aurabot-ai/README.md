# AuraBot AI for Glow Beauty Lounge

A working prototype of **AuraBot AI**, the booking concierge proposed for Glow Beauty Lounge, an imaginary high-end boutique salon (makeup, hair, skin, nails, lash and brow). Built for the CAPACITI Tech Career Accelerator Bootcamp AI Assistant project.

**Live demo:** [paste your deployed link here]

## The problem

Glow's schedule breaks down in four ways: appointment overlaps, duration mismatches, late cancellations and staff interruptions. Stylists stop work to answer messages, and empty slots appear too late to refill.

## What the application does

The page has two panels that share one live schedule.

**Client chat** (a WhatsApp-style conversation)
- Books, reschedules and cancels appointments in chat, by tapping options or typing.
- Shows only start times where the whole service fits and the specialist is free, so overlaps and duration mismatches cannot be booked.
- Takes a deposit step (simulated) and sends a prep guide on confirmation.
- Answers FAQs: hours, deposits, services and timings, cancellation policy, running late.
- Previews hairstyles with an illustrated preview (style and colour).
- Adds clients to a waitlist when a day is fully booked.
- Passes allergies, bridal parties, groups, refunds, complaints and requests for a person to senior management, and replies politely when it does not understand a request.

**Salon dashboard** (staff view)
- Schedule by specialist and day, with a button to simulate a client cancelling.
- Waitlist and offers: a freed slot is offered to the next waiting client and refilled when they accept.
- Escalations with a chat summary, so clients do not repeat themselves.
- Reminders queue and an activity log.

## Suggested demo flow (about 5 minutes)

1. Type *book a lash appointment*, pick a day and time, pay the demo deposit.
2. Type *can I reschedule* and move the booking.
3. Cancel the booking, then open the dashboard Waitlist tab and accept the offer for the next waiting client.
4. In the Schedule tab, select another client's booking and simulate a cancellation.
5. Type *I have a nut allergy* and open the Escalations tab.
6. Open Activity and send a reminder.
7. Type something unrelated, such as *what is the weather*, to show the fallback.

## How it works and its limits

- It is a **rule-based assistant**: it matches keywords and follows scripted conversation flows. It does not use a language model.
- Everything runs in the browser. There is no backend, database or real messaging. Refreshing the page or pressing **Reset demo** restores the example data.
- **Not real:** WhatsApp Business API and Instagram DM connections, payments, reminders sent on a timer, and photo-based hairstyle preview.
- Names, bookings, times, deposits, prep guides and the 24-hour cancellation policy are example values.
- Prices are not shown because they are not part of the proposal, and the bot says so.

## Tools used

- HTML, CSS and plain JavaScript in a single file (`index.html`), no framework or build step.
- Google Fonts (Cormorant Garamond, DM Sans).
- Built with the help of Claude (AI-assisted). All code was reviewed and tested by the group. [Edit this line to match what your group actually did.]
- GitHub for version control and sharing.

## How to run

Open `index.html` in any modern browser. To deploy, upload the file to a static host such as GitHub Pages, Netlify or Vercel.

## Possible future improvements

- Connect the WhatsApp Business API and Instagram DM.
- Add a language model for free-text understanding, with the same guardrails.
- Real deposit payments and a shared booking database.
- Automatic reminders on a timer.
- Hairstyle preview from the client's own photo.

## Team

[Member 1], [Member 2], [Member 3], [Member 4]. Add each member's area of contribution.

## Security

No passwords, API keys or tokens are stored in this repository. Do not commit any.
