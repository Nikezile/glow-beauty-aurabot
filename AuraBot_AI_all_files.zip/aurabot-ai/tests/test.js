const fs = require('fs');
const vm = require('vm');
const html = fs.readFileSync(process.argv[2], 'utf8');
const code = html.split('<script>')[1].split('</script>')[0];
const ctx = { window: { __FAST: true }, setTimeout, console, Promise, Date };
vm.createContext(ctx);
vm.runInContext(code, ctx);
const api = ctx.window.__api;
let fails = 0;
const ok = (c, m) => { if (!c) { fails++; console.log('FAIL', m); } else console.log('ok  ', m); };
const last = () => { const s = api.S(); return s.msgs[s.msgs.length - 1]; };
const chip = (pred) => last().chips.find(pred);

(async () => {
  await api.idle();
  ok(api.S().msgs.length === 1 && last().chips.length === 6, 'greeting with 6 menu chips');

  // 1. booking flow
  api.userText('book a lash appointment'); await api.idle();
  ok(last().chips.some(c => c.c.startsWith('day:')), 'lash -> day chips');
  const d0 = api.DAYS[0].key;
  api.userAct('day', 'day:' + d0); await api.idle();
  const timeChip = chip(c => c.c.startsWith('time:'));
  ok(!!timeChip, 'day -> time chips');
  api.userAct('t', timeChip.c); await api.idle();
  ok(!!chip(c => c.c === 'pay'), 'time -> deposit step');
  api.userAct('pay', 'pay'); await api.idle();
  const mine = api.S().bookings.filter(b => b.mine);
  ok(mine.length === 1 && api.S().stats.booked === 1, 'booking created');
  ok(api.S().reminders.length === 1, 'reminder queued');
  ok(/Prep guide/.test(last().html), 'prep guide sent on confirmation');

  // 2. overlap prevention
  const lashD1 = api.slotsFor('lash', api.DAYS[1].key);
  ok(lashD1.indexOf(600) >= 0 && lashD1.indexOf(630) < 0 && lashD1.indexOf(660) < 0 && lashD1.indexOf(690) < 0 && lashD1.indexOf(720) >= 0, 'overlap and duration respected (lash day 2)');
  const b = api.S().bookings;
  let overlaps = 0;
  for (const x of b) for (const y of b) if (x.id < y.id && x.spec === y.spec && x.day === y.day && x.start < y.start + y.dur && y.start < x.start + x.dur) overlaps++;
  ok(overlaps === 0, 'no overlapping bookings in state');
  ok(api.slotsFor('hair', api.DAYS[0].key).length === 0, 'hair fully booked day 1');

  // 3. waitlist join on full day
  api.userText('book hair'); await api.idle();
  api.userAct('day', 'day:' + api.DAYS[0].key); await api.idle();
  ok(!!chip(c => c.c === 'waitjoin'), 'full day offers waitlist');
  api.userAct('join', 'waitjoin'); await api.idle();
  ok(api.S().waitlist.some(w => w.mine), 'client on waitlist');
  // remove client from waitlist to keep later test deterministic
  api.S().waitlist = api.S().waitlist.filter(w => !w.mine);

  // 4. book hair day 2, cancel, refill from waitlist
  api.userText('book hair'); await api.idle();
  api.userAct('day', 'day:' + api.DAYS[1].key); await api.idle();
  api.userAct('t', 'time:660'); await api.idle();
  api.userAct('pay', 'pay'); await api.idle();
  const hairBk = api.S().bookings.find(x => x.mine && x.svc === 'hair');
  ok(!!hairBk && hairBk.start === 660, 'hair booked 11:00');
  api.userText('please cancel'); await api.idle();
  const pick = last().chips.find(c => c.c === 'bk:' + hairBk.id);
  ok(!!pick, 'cancel lists my booking');
  api.userAct('pick', pick.c); await api.idle();
  api.userAct('yes', 'cancel:yes'); await api.idle();
  ok(!api.S().bookings.some(x => x.id === hairBk.id), 'booking removed');
  const offer = api.S().offers[api.S().offers.length - 1];
  ok(offer && offer.status === 'sent', 'freed slot offered to waitlist');
  api.respondOffer(offer.id, true);
  ok(api.S().stats.refilled === 1 && api.S().bookings.some(x => x.client === 'Aisha M.' && x.start === 660), 'waitlist client refilled the slot');

  // 5. escalation
  api.userText('I have a nut allergy'); await api.idle();
  ok(api.S().esc.length === 1 && api.S().stats.escalated === 1, 'allergy escalated');
  api.dash('resolve:' + api.S().esc[0].id);
  ok(api.S().msgs[api.S().msgs.length - 1].from === 'mgr', 'manager reply appears in chat');

  // 6. fallback + faq + late
  api.userText('what is the weather like'); await api.idle();
  ok(api.S().stats.unrecognised === 1 && /can.t help/.test(last().html), 'unsupported request handled');
  api.userText('what are your opening hours'); await api.idle();
  ok(/09:00/.test(last().html), 'FAQ hours');
  api.userText('I am running late'); await api.idle();
  ok(/15 minutes/.test(last().html), 'late-arrival answer');

  // 7. reschedule
  api.userText('book skin'); await api.idle();
  api.userAct('day', 'day:' + api.DAYS[2].key); await api.idle();
  api.userAct('t', 'time:540'); await api.idle();
  api.userAct('pay', 'pay'); await api.idle();
  const skin = api.S().bookings.find(x => x.mine && x.svc === 'skin');
  ok(!!skin, 'skin booked');
  api.userText('can I reschedule'); await api.idle();
  api.userAct('pick', 'bk:' + skin.id); await api.idle();
  api.userAct('day', 'day:' + api.DAYS[3].key); await api.idle();
  api.userAct('t', 'time:600'); await api.idle();
  api.userAct('pay', 'pay'); await api.idle();
  const moved = api.S().bookings.find(x => x.id === skin.id);
  ok(moved.day === api.DAYS[3].key && moved.start === 600, 'booking rescheduled');

  // 8. free-text day and time parsing
  api.userText('hello'); await api.idle();
  api.userText('book nails'); await api.idle();
  api.userText('tomorrow'); await api.idle();
  ok(last().chips.some(c => c.c.startsWith('time:')), 'free-text day accepted');
  api.userText('14:00'); await api.idle();
  ok(!!chip(c => c.c === 'pay'), 'free-text time accepted');

  // 9. reset
  api.reset(); await api.idle();
  ok(api.S().msgs.length === 1 && api.S().bookings.length === 13, 'reset restores demo state');
  console.log(fails ? fails + ' FAILED' : 'ALL PASSED');
  process.exit(fails ? 1 : 0);
})();
